# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9009bfc4967542c5511d1541be4f1a08e880df4b52f02a8900f613f509678d4705792348590107c7c9d7a1e56d8ccdc48cb6453e6a489a9af2dcf8ffbb58344c'